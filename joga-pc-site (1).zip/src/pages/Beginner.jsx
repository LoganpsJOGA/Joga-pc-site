import React from 'react';

export default function Beginner() {
  return <div className="p-4 text-center text-xl font-bold">Beginner Page</div>;
}
