import React from 'react';

export default function MidTier() {
  return <div className="p-4 text-center text-xl font-bold">MidTier Page</div>;
}
