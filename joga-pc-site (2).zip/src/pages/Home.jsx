import React from 'react';

export default function Home() {
  return <div className="p-4 text-center text-xl font-bold">Home Page</div>;
}
