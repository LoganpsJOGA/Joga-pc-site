import React from 'react';

export default function HighEnd() {
  return <div className="p-4 text-center text-xl font-bold">HighEnd Page</div>;
}
